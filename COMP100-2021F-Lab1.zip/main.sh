#!/bin/sh
rm -r profiles2021
rm greeting.sh
echo '#!/bin/sh' >> greeting.sh
echo 'echo "Welcome to the club, user!"' >> greeting.sh
rm emails.txt
rm ids.txt
#my quiz starts here
#Q1
touch quiz.sh
echo #!/bin/sh > quiz.sh
#Q2
chmod a+x quiz.sh
chmod -rwxrwxrwx quiz.sh
#Q3 
echo 'cat profiles2021/Gülnisa.txt' > quiz.sh
#Q4
cp ./profiles2020/* profiles2021
