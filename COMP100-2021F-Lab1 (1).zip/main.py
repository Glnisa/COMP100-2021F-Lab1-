!/bin/sh
mkdir profiles2021
touch profiles2021/helin.txt
ls#!/bin/sh 

