cat profiles2021/Gülnisa.txt
